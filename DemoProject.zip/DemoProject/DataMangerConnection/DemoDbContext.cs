﻿using DataMangerConnection.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/// <summary>
/// Represents LeeCage Data Manger Connection dbContext project
/// </summary>
namespace DataMangerConnection
{
    /// <summary>
    ///represnt dbConnect Db Connect 
    /// </summary>
   public class DemoDbContext :DbContext
    {

        public DemoDbContext(DbContextOptions<DemoDbContext> options)
           : base(options)
        {
        }

        public DemoDbContext()
           : base()
        {
        }

        #region DbSet

        //Table
        public virtual DbSet<Person> Person { get; set; }

        #endregion



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            //modelBuilder.Entity<ResourceTeamMapping>().HasKey(c => new { c.ResourceId, c.TeamId });
        
        }
    }
}
