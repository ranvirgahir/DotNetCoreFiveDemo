﻿using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.NetworkInformation;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

/// <summary>
/// Represents Uproster common project layer
/// </summary>
namespace Common
{

    /// <summary>
    /// All the commom functions will be declared here for the application.
    /// </summary>
    public static class CommonFunction
    {

        public static string GenerateJSONWebToken(Guid userId, string userEmail, string userRole, string issuer, string key, string expiryTime, string UserRespJson, string userLoationId)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[] {
                new Claim(Constants.JwtTokenClaimType_UserId, Convert.ToString(userId)),
                new Claim(Constants.JwtTokenClaimType_UserEmail, userEmail),
                new Claim(Constants.JwtTokenClaimType_UserRole, userRole),
                new Claim(Constants.JwtTokenClaimType_UserRespJson, UserRespJson),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(Constants.JwtTokenClaimType_UserLocationID, userLoationId)

            };

            DateTime expirationTime = DateTime.Now.AddDays(Convert.ToDouble(expiryTime));
            var token = new JwtSecurityToken(issuer,
              issuer,
              claims,
              expires: expirationTime,
              signingCredentials: credentials);

            return string.Concat(new JwtSecurityTokenHandler().WriteToken(token), ",", Convert.ToString(expirationTime));
        }

        public static string HashPassword(string password, byte[] salt = null, bool needsOnlyHash = false)
        {
            if (salt == null || salt.Length != 16)
            {
                // generate a 128-bit salt using a secure PRNG
                salt = new byte[128 / 8];
                using (var rng = RandomNumberGenerator.Create())
                {
                    rng.GetBytes(salt);
                }
            }

            string hashed = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 10000,
                numBytesRequested: 256 / 8));

            if (needsOnlyHash) return hashed;
            // password will be concatenated with salt using ':'
            return $"{hashed}:{Convert.ToBase64String(salt)}";
        }

        public static bool VerifyPassword(string hashedPasswordWithSalt, string passwordToCheck)
        {
            // retrieve both salt and password from 'hashedPasswordWithSalt'
            var passwordAndHash = hashedPasswordWithSalt.Split(':');
            if (passwordAndHash == null || passwordAndHash.Length != 2)
                return false;
            var salt = Convert.FromBase64String(passwordAndHash[1]);
            if (salt == null)
                return false;
            // hash the given password
            var hashOfpasswordToCheck = HashPassword(passwordToCheck, salt, true);
            // compare both hashes
            if (String.Compare(passwordAndHash[0], hashOfpasswordToCheck) == 0)
            {
                return true;
            }
            return false;
        }

        public static string CreateRandomPassword(int length, string validCharacters)
        {
            Random random = new Random();
            char[] chars = new char[length];
            for (int i = 0; i < length; i++)
            {
                chars[i] = validCharacters[random.Next(0, validCharacters.Length)];
            }

            return new string(chars);
        }

        public static string GetIpAddress()
        {
            try
            {
                string hostname = Dns.GetHostName();
                string MyIpAddress = Dns.GetHostEntry(hostname).AddressList[1].ToString();
                return MyIpAddress;
            }
            catch
            {
                return "";
            }
        }

        public static string returnJsontoString(object value)
        {
            var resultjson = JsonConvert.SerializeObject(value);
            string result = resultjson.ToString();
            return result;
        }

        public static void sendEmail(string from, string to, string bodyMsg, string subject, string password, string host, int port, bool enableSsl, bool isBodyHmtl, bool useDefaultCredentials, string alias)
        {
            try
            {
                using (SmtpClient client = new SmtpClient(host))
                {
                    MailMessage mailMessage = new MailMessage();
                    mailMessage.From = new MailAddress(from, alias);
                    mailMessage.BodyEncoding = Encoding.UTF8;
                    mailMessage.To.Add(to);
                    mailMessage.Body = bodyMsg;
                    mailMessage.Subject = subject;
                    mailMessage.IsBodyHtml = isBodyHmtl;
                    client.Port = port;
                    client.EnableSsl = enableSsl;



                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                    client.UseDefaultCredentials = useDefaultCredentials;
                    client.Credentials = new NetworkCredential(from, password);
                    client.Send(mailMessage);
                }
            }
            catch (Exception ex)
            {

            }
        }

        public static string EncodeData(string any)
        {
            try
            {
                byte[] encData_byte = new byte[any.Length];
                encData_byte = Encoding.UTF8.GetBytes(any);
                string encodedData = Convert.ToBase64String(encData_byte);
                string result = randomString(20) + Constants.RandomString.RandomString1 + encodedData + Constants.RandomString.RandomString2 + randomString(25);
                return result;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public static string DecodeData(string encodedData)
        {
            string str1 = encodedData.Split(Constants.RandomString.RandomString1)[1];
            string str2 = str1.Split(Constants.RandomString.RandomString2)[0];
            UTF8Encoding encoder = new UTF8Encoding();
            Decoder utf8Decode = encoder.GetDecoder();
            byte[] todecode_byte = Convert.FromBase64String(str2);
            int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
            char[] decoded_char = new char[charCount];
            utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
            string result = new String(decoded_char);
            return result;
        }

        public static string randomString(int length)
        {
            Random random = new Random();
            string chars = "abcdefghijklmnopqrstuvwxyz0123456789";
            string result = new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
            return result;
        }

        public static string RegexPatternCheckforDomainNamebyHostingkeyword(string domainname)
        {

            string domainNameStartValue = "";
            string[] domainnamepattern = Regex.Split(domainname, @"\d+");
            if (domainnamepattern != null)
            {

                domainNameStartValue = domainnamepattern[0].Trim();

            }

            return domainNameStartValue;

        }
        //DomainName Validation
        public static bool RegexPatternCheckforDomain(string domainname)
        {

            // Create a pattern for a word   
            string pattern = @"^[a-zA-Z][a-zA-Z0-9]*$";
            // Create a Regex  
            Regex rg = new Regex(pattern);

            // Long string  
            string domainnamePatterntoMatch = domainname;
            // Get all matches  
            MatchCollection domainnamePattern = rg.Matches(domainnamePatterntoMatch);
            // Print all matched authors  
            if (domainnamePattern.Count > 0)
            {
                return true;
            }

            return false;

        }
        //Password Validation
        public static bool PasswordValidator(string password)
        {

            // Create a pattern for a word   
            string pattern = @"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$";
            // Create a Regex  
            Regex rg = new Regex(pattern);

            // Long string  
            string passwordPatterntoMatch = password;
            // Get all matches  
            MatchCollection passwordPattern = rg.Matches(passwordPatterntoMatch);
            // Print all matched authors  
            if (passwordPattern.Count > 0)
            {
                return true;
            }


            return false;

        }

        //ValidateGuid
        public static bool isvalidGuid(string Guid)
        {

            // Create a pattern for a word   
            string pattern = @"^[{]?[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}[}]?$";
            // Create a Regex  
            Regex rg = new Regex(pattern);

            // Long string  
            string GuidPatterntoMatch = Guid;
            // Get all matches  
            MatchCollection GuidPattern = rg.Matches(GuidPatterntoMatch);
            // Print all matched authors  
            if (GuidPattern.Count > 0)
            {
                return true;
            }

            return false;

        }

        //ComapanyName to suggested domainName
        public static string CompanyNametoSuggestedDomainName(string CompanyName)
        {


            var SuggesteddomainName = "";
            // Create a pattern for a word   
            var pattern = CompanyName.Trim().Split(" ");

            foreach (var item in pattern)
            {

                if (item != "")
                {
                    SuggesteddomainName += item.Substring(0, 1).ToUpper();
                }
            }
            while (SuggesteddomainName.Length < 3)
            {

                Random random = new Random();
                var randomNumber = random.Next(0, 3);
                SuggesteddomainName += SuggesteddomainName + randomNumber;


            }



            return SuggesteddomainName;

        }

        public static void LogFile(string filepath, string Message)
        {



            filepath = filepath + Path.DirectorySeparatorChar.ToString() + "Logs" + Path.DirectorySeparatorChar.ToString()
                                                           + "LogFile.txt";

            StreamWriter log;
            if (!System.IO.File.Exists(filepath))
            {
                log = new StreamWriter(filepath);
            }
            else
            {
                log = System.IO.File.AppendText(filepath);
            }

            //log.WriteLine("Error :" + Message);
            log.WriteLine("Date Time:" + DateTime.UtcNow);
            log.WriteLine(Message);
            log.WriteLine("<============================================================================================================>");
            //log.WriteLine("\n");
            log.Close();
        }


        public static string GetMacAddress()
        {
            try
            {
                string addr = "";
                foreach (NetworkInterface n in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (n.OperationalStatus == OperationalStatus.Up)
                    {
                        addr += n.GetPhysicalAddress().ToString();
                        break;
                    }
                }
                return addr;
            }
            catch
            {
                return "";
            }

        }

        public static int ConvertToTime(double timeSeconds)

        {

            int mySeconds = System.Convert.ToInt32(timeSeconds);

            int myHours = mySeconds / 3600; //3600 Seconds in 1 hour

            mySeconds %= 3600;

            int myMinutes = mySeconds / 60; //60 Seconds in a minute

            mySeconds %= 60;

            string mySec = mySeconds.ToString(),

            myMin = myMinutes.ToString(),

            myHou = myHours.ToString();

            if (myHours < 10) { myHou = myHou.Insert(0, "0"); }

            if (myMinutes < 10) { myMin = myMin.Insert(0, "0"); }

            if (mySeconds < 10) { mySec = mySec.Insert(0, "0"); }

            return myHours;

        }

        public static long ConvertToSeconds(decimal hours = 0)
        {

            long seconds = Convert.ToInt64(hours * 60 * 60);

            return seconds;

        }

        #region Validation Functions

        //we use EmailValidator from FluentValidation. So let's keep them sync - https://github.com/JeremySkinner/FluentValidation/blob/master/src/FluentValidation/Validators/EmailValidator.cs
        private const string EMAIL_EXPRESSION = @"^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-||_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+([a-z]+|\d|-|\.{0,1}|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])?([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$";

        private static readonly Regex _emailRegex;

        /// <summary>
        /// Verifies that a string is in valid e-mail format
        /// </summary>
        /// <param name="email">Email to verify</param>
        /// <returns>true if the string is a valid e-mail address and false if it's not</returns>
        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrEmpty(email))
                return false;

            email = email.Trim();

            return _emailRegex.IsMatch(email);
        }


        /// <summary>
        /// Verifies that string is an valid IP-Address
        /// </summary>
        /// <param name="ipAddress">IPAddress to verify</param>
        /// <returns>true if the string is a valid IpAddress and false if it's not</returns>
        public static bool IsValidIpAddress(string ipAddress)
        {
            return IPAddress.TryParse(ipAddress, out var _);
        }

        /// <summary>
        /// Ensures that a string only contains numeric values
        /// </summary>
        /// <param name="str">Input string</param>
        /// <returns>Input string with only numeric values, empty string if input is null/empty</returns>
        public static string EnsureNumericOnly(string str)
        {
            return string.IsNullOrEmpty(str) ? string.Empty : new string(str.Where(char.IsDigit).ToArray());
        }

        /// <summary>
        /// Ensure that a string is not null
        /// </summary>
        /// <param name="str">Input string</param>
        /// <returns>Result</returns>
        public static string EnsureNotNull(string str)
        {
            return str ?? string.Empty;
        }


        #endregion

        #region Date Time Functions

        public static string IsTimeValid(string time)
        {
            string returnValidTIme = string.Empty;

            string ReturnVal = string.Empty;
            string Hourstt = string.Empty;
            string Replacestring = string.Empty;
            string hours = string.Empty;
            string minture = string.Empty;

            #region Set and Get Time

            if (!string.IsNullOrEmpty(time))
            {
                if (!time.StartsWith("0"))
                {
                    //time = "0" + time;
                    time = time;
                }

                if (time.ToLower().Contains("am") || time.ToLower().Contains("pm"))
                {
                    if (time.Contains(":"))
                    {
                        if (time.ToLower().Contains("am"))
                        {
                            ReturnVal = time.ToLower().Trim();
                            if (ReturnVal.Contains(" am"))
                            {
                                ReturnVal = ReturnVal.Replace(" am", "");
                            }
                            else
                            {
                                ReturnVal = ReturnVal.Replace("am", "");
                            }
                            Hourstt = ReturnVal.Substring(0, ReturnVal.IndexOf(":"));
                            int convertehours = 0;
                            if (Convert.ToInt32(Hourstt) > 11)
                            {
                                convertehours = Convert.ToInt32(0);
                                Replacestring = convertehours.ToString() + "0" + ReturnVal.Substring(ReturnVal.IndexOf(":"));
                                ReturnVal = Replacestring;
                            }
                        }
                        else
                        {
                            ReturnVal = time.ToLower().Trim();
                            if (ReturnVal.Contains(" pm"))
                            {
                                ReturnVal = ReturnVal.Replace(" pm", "");
                            }
                            else
                            {
                                ReturnVal = ReturnVal.Replace("pm", "");
                            }

                            Hourstt = ReturnVal.Substring(0, ReturnVal.IndexOf(":"));
                            int convertehours = 0;
                            if (Convert.ToInt32(Hourstt) > 11)
                            {
                                convertehours = Convert.ToInt32(Hourstt);
                            }
                            else
                            {
                                convertehours = Convert.ToInt32(Hourstt) + 12;
                            }
                            Replacestring = convertehours.ToString() + ReturnVal.Substring(ReturnVal.IndexOf(":"));
                            ReturnVal = Replacestring;
                        }
                    }
                    else
                    {
                        if (time.Length == 4)
                        {
                            ReturnVal = time.ToLower().Trim();
                            hours = ReturnVal.Substring(0, 2);
                            minture = ReturnVal.Substring(2, 2);
                            Replacestring = hours + ":" + minture;
                            ReturnVal = Replacestring;
                        }
                    }
                }
                else
                {
                    if (time.Contains(":"))
                    {
                        ReturnVal = time.ToLower().Trim();
                        Hourstt = ReturnVal.Substring(0, ReturnVal.IndexOf(":"));
                        if (Hourstt.Length == 1)
                            Replacestring = "0" + Hourstt.ToString() + ReturnVal.Substring(ReturnVal.IndexOf(":"));
                        else
                            Replacestring = Hourstt.ToString() + ReturnVal.Substring(ReturnVal.IndexOf(":"));
                        ReturnVal = Replacestring;

                    }
                    else
                    {
                        if (time.Length == 4)
                        {
                            ReturnVal = time.ToLower().Trim();
                            hours = ReturnVal.Substring(0, 2);
                            minture = ReturnVal.Substring(2, 2);
                            Replacestring = hours + ":" + minture;
                            ReturnVal = Replacestring;
                        }
                    }
                }
            }

            #endregion

            if (!string.IsNullOrEmpty(ReturnVal))
            {
                try
                {
                    returnValidTIme = ReturnVal.ToString();
                }
                catch { }
            }

            return returnValidTIme;
        }

        public static TimeSpan? GetValidTime(string time)
        {
            TimeSpan? Returnvalues = null;

            string ReturnVal = string.Empty;
            string Hourstt = string.Empty;
            string Replacestring = string.Empty;
            string hours = string.Empty;
            string minture = string.Empty;

            #region Set and Get Time

            if (time.ToLower().Contains("am") || time.ToLower().Contains("pm"))
            {
                if (time.Contains(":"))
                {
                    if (time.ToLower().Contains("am"))
                    {
                        ReturnVal = time.ToLower().Trim();
                        if (ReturnVal.Contains(" am"))
                        {
                            ReturnVal = ReturnVal.Replace(" am", "");
                        }
                        else
                        {
                            ReturnVal = ReturnVal.Replace("am", "");
                        }
                        Hourstt = ReturnVal.Substring(0, ReturnVal.IndexOf(":"));
                        int convertehours = 0;
                        if (Convert.ToInt32(Hourstt) > 11)
                        {
                            convertehours = Convert.ToInt32(0);
                            Replacestring = convertehours.ToString() + ReturnVal.Substring(ReturnVal.IndexOf(":"));
                            ReturnVal = Replacestring;
                        }
                    }
                    else
                    {
                        ReturnVal = time.ToLower().Trim();
                        if (ReturnVal.Contains(" pm"))
                        {
                            ReturnVal = ReturnVal.Replace(" pm", "");
                        }
                        else
                        {
                            ReturnVal = ReturnVal.Replace("pm", "");
                        }

                        Hourstt = ReturnVal.Substring(0, ReturnVal.IndexOf(":"));
                        int convertehours = 0;
                        if (Convert.ToInt32(Hourstt) > 11)
                        {
                            convertehours = Convert.ToInt32(Hourstt);
                        }
                        else
                        {
                            convertehours = Convert.ToInt32(Hourstt) + 12;
                        }
                        Replacestring = convertehours.ToString() + ReturnVal.Substring(ReturnVal.IndexOf(":"));
                        ReturnVal = Replacestring;
                    }
                }
                else
                {
                    if (time.Length == 4)
                    {
                        ReturnVal = time.ToLower().Trim();
                        hours = ReturnVal.Substring(0, 2);
                        minture = ReturnVal.Substring(2, 2);
                        Replacestring = hours + ":" + minture;
                        ReturnVal = Replacestring;
                    }
                }
            }
            else
            {
                if (time.Contains(":"))
                {
                    ReturnVal = time.ToLower().Trim();
                    Hourstt = ReturnVal.Substring(0, ReturnVal.IndexOf(":"));
                    if (Hourstt.Length == 1)
                        Replacestring = "0" + Hourstt.ToString() + ReturnVal.Substring(ReturnVal.IndexOf(":"));
                    else
                        Replacestring = Hourstt.ToString() + ReturnVal.Substring(ReturnVal.IndexOf(":"));
                    ReturnVal = Replacestring;

                }
                else
                {
                    if (time.Length == 4)
                    {
                        ReturnVal = time.ToLower().Trim();
                        hours = ReturnVal.Substring(0, 2);
                        minture = ReturnVal.Substring(2, 2);
                        Replacestring = hours + ":" + minture;
                        ReturnVal = Replacestring;
                    }
                }
            }
            #endregion

            if (!string.IsNullOrEmpty(ReturnVal))
            {
                try
                {
                    Returnvalues = TimeSpan.Parse(ReturnVal);
                }
                catch { }
            }

            return Returnvalues;
        }

        public static TimeSpan? ConvertStringToTime(string time)
        {
            DateTime dt = DateTime.Parse(time);
            TimeSpan? ts = new TimeSpan(dt.Hour, dt.Minute, dt.Second);
            return ts;
        }

        public static string GetHour(DateTime dt)
        {
            int Hour = dt.Hour;
            if (Hour <= 9)
            {
                return "0" + Hour.ToString();
            }
            else
            {
                switch (Hour)
                {
                    case 10:
                        return "10";
                    case 11:
                        return "11";
                    case 12:
                        return "12";
                    case 13:
                        return "01";
                    case 14:
                        return "02";
                    case 15:
                        return "03";
                    case 16:
                        return "04";
                    case 17:
                        return "05";
                    case 18:
                        return "06";
                    case 19:
                        return "07";
                    case 20:
                        return "08";
                    case 21:
                        return "09";
                    case 22:
                        return "10";
                    case 23:
                        return "11";
                    case 24:
                        return "12";
                    default:
                        return "00";
                }
            }
        }

        public static long ConvertDatetimeToUnixTimeStamp(DateTime dateTime)
        {
            TimeSpan timeSpan = dateTime - new DateTime(1970, 1, 1, 0, 0, 0);

            return (long)timeSpan.TotalSeconds;
        }

        /// <summary>
        /// Get difference in years
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public static int GetDifferenceInYears(DateTime startDate, DateTime endDate)
        {
            //source: http://stackoverflow.com/questions/9/how-do-i-calculate-someones-age-in-c
            //this assumes you are looking for the western idea of age and not using East Asian reckoning.
            var age = endDate.Year - startDate.Year;
            if (startDate > endDate.AddYears(-age))
                age--;
            return age;
        }

        public static string GetExperience(DateTime? startDate, string format)
        {
            if (startDate != null && startDate != new DateTime() && !(startDate > DateTime.UtcNow))
                return new Age((DateTime)startDate, DateTime.Today, format).AgeString;
            else
                return string.Empty;
        }
        public static string GetExperienceInMonths(DateTime? startDate)
        {
            if (startDate != null && startDate != new DateTime() && !(startDate > DateTime.UtcNow))
            {
                DateTime startdate = (DateTime)startDate;
                int resultMonths = Convert.ToInt32(((DateTime.UtcNow.Year - startdate.Year) * 12) + DateTime.UtcNow.Month - startdate.Month);
                return String.Format("{0} mth", resultMonths);
            }
            else
            {
                return string.Empty;
            }
        }

        #endregion

        #region SQL Helper

        public static class SQLQueryHelper
        {
            public static string GetIntValueOrNullString(int? source)
            {
                if (source.HasValue)
                {
                    return source.Value.ToString();
                }
                else
                {
                    return "NULL";
                }
            }

            public static string GetDecimalValueOrNullString(decimal? source)
            {
                if (source.HasValue)
                {
                    return source.Value.ToString();
                }
                else
                {
                    return "NULL";
                }
            }

            public static string GetDoubleValueOrNullString(double? source)
            {
                if (source.HasValue)
                {
                    return source.Value.ToString();
                }
                else
                {
                    return "NULL";
                }
            }

            public static string GetDateTimeValueOrNullString(DateTime? source)
            {
                if (source.HasValue)
                {
                    return "'" + source.Value.ToString("MM/dd/yyyy HH:mm:ss") + "'";
                }
                else
                {
                    return "NULL";
                }
            }

            public static string GetTimeSpanValueOrNullString(TimeSpan? source)
            {
                if (source.HasValue)
                {
                    return "'" + source.Value.ToString() + "'";
                }
                else
                {
                    return "NULL";
                }
            }

            public static string GetStringValueOrNullString(string source)
            {
                if (!string.IsNullOrWhiteSpace(source))
                {
                    return "'" + source.ToString().Replace("'", "''").Replace("\0", "\\0") + "'";
                }
                else
                {
                    return "NULL";
                }
            }

        }

        #endregion

        #region Unit Conversions

        public static double ConvertMilesToKilometers(double miles)
        {
            //
            // Multiply by this constant and return the result.
            //
            return miles * 1.609344;
        }

        public static double ConvertKilometersToMiles(double kilometers)
        {
            //
            // Multiply by this constant.
            //
            return kilometers * 0.621371192;
        }

        #endregion

        //Round Off Decimal Place
        public static decimal RoundOff(decimal input, int places)
        {
            double multiplier = Math.Pow(10, Convert.ToDouble(places));
            var result = Math.Ceiling(Convert.ToDouble(input) * multiplier) / multiplier;
            return Convert.ToDecimal(result);
        }

        //public static string setBodyEmail(string bodyHtml,List<string> paramsEmail)
        //{
        //    SendEmailTemplateValues sendEmailTemplateValues = new SendEmailTemplateValues();
        //    string outputstring = "";
        //    foreach (var param in paramsEmail.Select((value, i) => new { i, value }))
        //    {
        //        outputstring = bodyHtml.Replace("{"+ param.i +"}", param.value);
        //        bodyHtml = outputstring;
                
               
        //    }

        //    return sendEmailTemplateValues.EmailParamValues;
        //}
    }

    public static class ListExtensions
    {
        public static DataTable ToDataTable<T>(this List<T> iList)
        {
            DataTable dataTable = new DataTable();
            PropertyDescriptorCollection propertyDescriptorCollection =
                TypeDescriptor.GetProperties(typeof(T));
            for (int i = 0; i < propertyDescriptorCollection.Count; i++)
            {
                PropertyDescriptor propertyDescriptor = propertyDescriptorCollection[i];
                Type type = propertyDescriptor.PropertyType;

                if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
                    type = Nullable.GetUnderlyingType(type);


                dataTable.Columns.Add(propertyDescriptor.Name, type);
            }
            object[] values = new object[propertyDescriptorCollection.Count];
            foreach (T iListItem in iList)
            {
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = propertyDescriptorCollection[i].GetValue(iListItem);
                }
                dataTable.Rows.Add(values);
            }
            return dataTable;
        }

        public static List<SelectListItem> ToSelectList<TEnum>(this TEnum obj)
        {
            return Enum.GetValues(typeof(TEnum)).OfType<Enum>()
                .Select(x =>
                    new SelectListItem
                    {
                        Text = Enum.GetName(typeof(TEnum), x),
                        Value = (Convert.ToInt32(x)).ToString()
                    }).ToList();
        }
    }

    public class Age
    {
        public int Years;
        public int Months;
        public int Days;
        public string format;

        public Age(DateTime Bday, string format)
        {
            this.Count(Bday, format);
        }

        public Age(DateTime Bday, DateTime Cday, string format)
        {
            this.Count(Bday, Cday, format);
        }

        public Age Count(DateTime Bday, string format)
        {
            return this.Count(Bday, DateTime.Today, format);
        }

        public Age Count(DateTime Bday, DateTime Cday, string format)
        {
            this.format = format;

            if ((Cday.Year - Bday.Year) > 0 ||
                (((Cday.Year - Bday.Year) == 0) && ((Bday.Month < Cday.Month) ||
                  ((Bday.Month == Cday.Month) && (Bday.Day <= Cday.Day)))))
            {
                int DaysInBdayMonth = DateTime.DaysInMonth(Bday.Year, Bday.Month);
                int DaysRemain = Cday.Day + (DaysInBdayMonth - Bday.Day);

                if (Cday.Month > Bday.Month)
                {
                    this.Years = Cday.Year - Bday.Year;
                    this.Months = Cday.Month - (Bday.Month + 1) + Math.Abs(DaysRemain / DaysInBdayMonth);
                    this.Days = (DaysRemain % DaysInBdayMonth + DaysInBdayMonth) % DaysInBdayMonth;
                }
                else if (Cday.Month == Bday.Month)
                {
                    if (Cday.Day >= Bday.Day)
                    {
                        this.Years = Cday.Year - Bday.Year;
                        this.Months = 0;
                        this.Days = Cday.Day - Bday.Day;
                    }
                    else
                    {
                        this.Years = (Cday.Year - 1) - Bday.Year;
                        this.Months = 11;
                        this.Days = DateTime.DaysInMonth(Bday.Year, Bday.Month) - (Bday.Day - Cday.Day);
                    }
                }
                else
                {
                    this.Years = (Cday.Year - 1) - Bday.Year;
                    this.Months = Cday.Month + (11 - Bday.Month) + Math.Abs(DaysRemain / DaysInBdayMonth);
                    this.Days = (DaysRemain % DaysInBdayMonth + DaysInBdayMonth) % DaysInBdayMonth;
                }
            }
            else
            {
                this.Years = 0;
                this.Months = 0;
                this.Days = 0;
            }
            return this;
        }
        public string AgeString
        {
            get
            {
                string ageString = string.Empty;
                if (!string.IsNullOrEmpty(format))
                {
                    if (format.ToLower() == "mm")
                    {
                        var newMonths = Math.Floor((decimal)((Years * 12) + Months + (Days / 30)));
                        if (newMonths >= 1)
                        {
                            if (newMonths == 1)
                            {
                                ageString = string.Format("{0} mth", newMonths);
                            }
                            else
                            {
                                ageString = string.Format("{0} mth", newMonths);
                            }
                        }
                        else
                        {
                            ageString = string.Format("{0} mth", 1);
                        }
                    }
                }
                else
                {
                    if (Years >= 1)
                    {
                        if (Years == 1)
                        {
                            ageString = string.Format("{0} Year", Years);
                        }
                        else
                        {
                            ageString = string.Format("{0} Years", Years);
                        }
                    }
                    if (Months >= 1)
                    {
                        if (Months == 1)
                        {
                            ageString += string.Format(" {0} Month", Months);
                        }
                        else
                        {
                            ageString += string.Format(" {0} Months", Months);
                        }
                    }
                    if (Days >= 1)
                    {
                        if (Days == 1)
                        {
                            ageString += string.Format(" {0} Day", Days);
                        }
                        else
                        {
                            ageString += string.Format(" {0} Days", Days);
                        }
                    }
                }
                return ageString;
            }
        }
    }

    //public class SendEmailTemplateValues
    //{
    //    public string EmailParamValues { get; set; }

        
    //}

}
