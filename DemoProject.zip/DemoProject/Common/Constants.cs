﻿using System;

namespace Common
{
    public class Constants
    {
        #region Encoding and Decoding
        public static class RandomString
        {
            public const string RandomString1 = "hiimj";
            public const string RandomString2 = "mjiih";
        }
        #endregion


        #region App Settings
        public const string AppSettings = "AppSettings";
            public const string ConnectionSettingPath = "AppSettings:ConnectionStrings:DbConnection";
            public const string ConnectionStringsSectionName = "ConnectionStrings";
            public const string API_DbConnection = "API_DbConnection";
            public static readonly string DisplayDateFormat = "MM/dd/yyyy hh:mm tt";
            public static readonly string RoadmapFlowDisplayMonthFormat = "MMM-yyyy";
            public const string JwtTokenClaimType_UserId = "UserId";
            public const string JwtTokenClaimType_UserEmail = "UserEmail";
            public const string JwtTokenClaimType_UserRespJson = "UserRespJson";
            public const string JwtTokenClaimType_UserLocationID = "UserLocationID";
            public const string JwtTokenClaimType_CompanyID = "CompanyId";
            public const string JwtTokenClaimType_UserRole = "UserRole";
            public const string ProjectSourceWEB = "WEB";
            public const string ProjectSourceAPI = "API";
            #endregion


            /// <summary>
            /// This class contains all the messages throughout the application
            /// </summary>
            /// 
            #region ApiResponse Messages 
            public static class Messages
            {
                public const string Success = "Success";
                public const string Failed = "Failed";
                public const string BadRequest = "Bad Request";
                public const string UserDoesNotExist = "User does not exists.";
                public const string UserDisabled = "Your Account is disabled, Please contact your Admin.";
                public const string UserAlreadyExists = "User already exists for the entered email address.";
                public const string DataAlreadyExists = "Record already exists for the entered Data.";
                public const string InvalidLogin = "Incorrect password, Please try Again.";
                public const string InternalServerError = "Internal server error.";
                public const string NotDataExistsInTable = "No data exists in table.";
                public const string RecordNotFound = "Record not found.";
                public const string AccessDenied = "Your account does not have permission to perform this action.";
                public const string GroupNotExist = "Group does not exists.";
                public const string GroupAlreadyExist = "Group already exists for the entered name.";
                public const string CheckEmail = "Please check your email to reset password.";
                public const string ResetLinkExpire = "This link has Expired, Please go to Forgot Password Section.";
                public const string EnterName = "Please enter Name.";
                public const string RoleAlreadyExist = "Role already exists for the entered name.";
                public const string DesignationAlreadyExist = "Designation already exists for the entered name.";
                public const string DepartmentAlreadyExist = "Department already exists for the entered name.";
                public const string LocationNotExist = "Location does not exists.";
                public const string LocationAlreadyExist = "Location already exists for the entered name.";
                public const string ValidationErrors = "One or more Validation Errors Occurred.";

                //Password
                public const string PasswordChangedSuccess = "Password has been changed successfully.";
                public const string IncorrectOldPassword = "Old password is Incorrect.";
                public const string PasswordResetSuccess = "Password Reset Successfully";
                public const string IncorrectTempPassword = "Incorrect Temporary Password";
                public const string PasswordNotMatch = "Confirm password does not match.";
                public const string SamePasswordMatch = "Old and New Password cannot be Same.";

                //Profile Image Upload Messages
                public const string UserProfileImageUpdated = "User profile image updated successfully";
                public const string InvalidFile = "Please select a valid image to upload.";

            }
            #endregion

            /// <summary>
            /// This class contains all the static attribute names throughout the application
            /// </summary>
            /// 
            #region Api Attributes 
            public static class Attrributes
            {
                public const string Id = "{id}";
                public const string Api_LeeCage_Version_Prefix = "CoreFiveApi/v1";
                public const string Api_Prefix = "api";
                public const string ApiDefaultRoute = "CoreFiveApi/v1/api/[controller]/";
                public const string ApiRouteNoController = "CoreFiveApi/v1/api/";

                public const string GetApiName = "get";
                public const string GetByIdApiName = "get/{id}";
                public const string ListApiName = "all";
                public const string InsertApiName = "insert";
                public const string UpdateApiName = "update/{id}";
                public const string DeleteApiName = "delete";
                public const string Exception = "exception";
                public const string MessageRollBack = "MessageRollBack";
            }
            #endregion


            /// <summary>
            /// Constants will be declared here for the SwaggerSettings.
            /// </summary>
            public static class SwaggerSettings
            {
                public const string RootSectionName = "SwaggerSettings";
                public const string Name = "Name";
                public const string Url = "Url";
            }
        }
    }

