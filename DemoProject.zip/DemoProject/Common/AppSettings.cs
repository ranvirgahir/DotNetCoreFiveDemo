﻿
namespace Common
{
    /// <summary>
    /// This class represents the sections defined in appSettings.json
    /// </summary>
    public class AppSettings
    {

        public ConnectionStrings connectionStrings { get; set; }

        public class ConnectionStrings
        {
            public string DbConnection { get; set; }
        }

    }
}
