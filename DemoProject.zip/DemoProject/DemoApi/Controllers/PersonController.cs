﻿using ApiService.IApiService;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DemoApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PersonController : /*Controller*/  ControllerBase
    {
        private readonly ICommonService commonService;

        public PersonController(ICommonService commonService)
        {
            this.commonService = commonService;
        }

        /// <summary>
        /// Index
        /// </summary>
        /// <returns></returns>
        [HttpGet("Index")]
        public IActionResult Index()
        {
            return Ok(commonService.GetAllList());
        }

      
       /// <summary>
       /// Details
       /// </summary>
       /// <param name="id"></param>
       /// <returns></returns>
        [HttpGet("Details")]
       
        public IActionResult Details(int id)
        {
            return Ok(commonService.GetDetails());
        }


        /// <summary>
        /// Create
        /// </summary>
        /// <returns></returns>
        [HttpPost("Create")]
        public IActionResult Create()
        {
            try
            {
                return Ok();
            }
            catch
            {
                return Ok();
            }
        }

        

      
        /// <summary>
        /// Edit
        /// </summary>
        /// <returns></returns>
        [HttpPut("Edit")]
     
        public IActionResult Edit()
        {
            try
            {
                return Ok();
            }
            catch
            {
                return Ok();
            }
        }

       

      
        /// <summary>
        /// Delete
        /// </summary>
        /// <returns></returns>
        [HttpDelete("Delete")]
   
        public IActionResult Delete()
        {
            try
            {
                return Ok();
            }
            catch
            {
                return Ok();
            }
        }
    }
}
