﻿using DataMangerConnection.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiService.IApiService
{
  public  interface ICommonService
    {
        /// <summary>
        /// Get All data from Table  
        /// </summary>
        /// <returns></returns>
        IEnumerable<Person> GetAllList();
        /// <summary>
        /// Get Single Data from Table
        /// </summary>
        /// <returns></returns>
        Person GetDetails();

    }
}
