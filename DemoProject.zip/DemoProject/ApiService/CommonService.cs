﻿using ApiService.IApiService;
using DataMangerConnection.Model;
using Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiService
{
    /// <summary>
    /// Repesent Common Service class which interact with repository
    /// </summary>
    public class CommonService : ICommonService
    {
        private readonly ICommonRepository commonRepository;
        /// <summary>
        /// Repository dependncy Injection
        /// </summary>
        /// <param name="commonRepository"></param>
        public CommonService(ICommonRepository commonRepository)
        {
            this.commonRepository = commonRepository;
        }

        public IEnumerable<Person> GetAllList() {

            List<Person> people = new();
            people = commonRepository.GetAll().ToList();
            return people;
        }
        public Person GetDetails()
        {

           Person people = new();
            people = commonRepository.GetAll().FirstOrDefault();
            return people;
        }
    }
}
